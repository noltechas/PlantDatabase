import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PlantDBServlet")
public class PlantDBServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
   static String url = "jdbc:mysql://ec2-3-85-170-11.compute-1.amazonaws.com:3306/Plants?useSSL=false";
   static String user = "mbell_remote";
   static String password = "password";
   static Connection connection = null;

   public PlantDBServlet() {
      super();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
      response.getWriter().println("-------- MySQL JDBC Connection Testing ------------<br>");
      try {
         Class.forName("com.mysql.cj.jdbc.Driver"); //old:com.mysql.jdbc.Driver
      } catch (ClassNotFoundException e) {
         System.out.println("Where is your MySQL JDBC Driver?");
         e.printStackTrace();
         return;
      }
      response.getWriter().println("MySQL JDBC Driver Registered!<br>");
      connection = null;
      try {
         connection = DriverManager.getConnection(url, user, password);
      } catch (SQLException e) {
         System.out.println("Connection Failed! Check output console");
         e.printStackTrace();
         return;
      }
      if (connection != null) {
         response.getWriter().println("You made it, take control your database now!<br>");
      } else {
         System.out.println("Failed to make connection!");
      }
      try {
         String selectSQL = "SELECT * FROM Plants WHERE NAME LIKE ? OR water LIKE ? OR soil LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?";
         
         String plantName = "name%";
         String plantWater= "water%";
         String plantSoil = "soil%";
         String plantSunlight = "sunlight%";
         String plantFertilizer = "fertilizer%";
         response.getWriter().println(selectSQL + "<br>");
         response.getWriter().println("------------------------------------------<br>");
         PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
         preparedStatement.setString(1, plantName);
         preparedStatement.setString(2, plantWater);
         preparedStatement.setString(3, plantSoil);
         preparedStatement.setString(4, plantSunlight);
         preparedStatement.setString(5, plantFertilizer);
         ResultSet rs = preparedStatement.executeQuery();
         while (rs.next()) {
            String name = rs.getString("name");
            String water = rs.getString("water");
            String soil = rs.getString("soil");
            String sunlight = rs.getString("sunlight");
            String fertilizer = rs.getString("fertilizer");
            response.getWriter().append("Plant Name: " + name + ", ");
            response.getWriter().append("Water: " + water + ", ");
            response.getWriter().append("Soil: " + soil + ", ");
            response.getWriter().append("Sunlight: " + sunlight + ", ");
            response.getWriter().append("Fertilizer: " + fertilizer + "<br>");
         }
         preparedStatement.close();
         connection.close();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }
}
