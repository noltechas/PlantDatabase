import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InsertPlants")
public class InsertPlants extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public InsertPlants() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String water = request.getParameter("water");
		String soil = request.getParameter("soil");
		String sunlight = request.getParameter("sunlight");
		String fertilizer = request.getParameter("fertilizer");
		String other = request.getParameter("other");

		Connection connection = null;
		String insertSql = "INSERT INTO Plants (id, NAME, WATER, SOIL, SUNLIGHT, FERTILIZER, OTHER) values (default, ?, ?, ?, ?, ?, ?)";

		try {
			PlantDBConnection.getDBConnection();
			connection = PlantDBConnection.connection;
			PreparedStatement preparedStmt = connection.prepareStatement(insertSql);
			preparedStmt.setString(1, name);
			preparedStmt.setString(2, water);
			preparedStmt.setString(3, soil);
			preparedStmt.setString(4, sunlight);
			preparedStmt.setString(5, fertilizer);
			preparedStmt.setString(6,  other);
			preparedStmt.execute();
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Set response content type
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title = "Insert Data to DB table";
		String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
		out.println(docType + //
				"<html>\n" + //
				"<head><title>" + title + "</title></head>\n" + //
				"<body bgcolor=\"#f0f0f0\">\n" + //
				"<h2 align=\"center\">" + title + "</h2>\n" + //
				"<ul>\n" + //

				"  <li><b>Plant Name</b>: " + name + "\n" + //
				"  <li><b>Water</b>: " + water + "\n" + //
				"  <li><b>Soil</b>: " + soil + "\n" + //
				"  <li><b>Sunlight</b>: " + sunlight + "\n" + //
				"  <li><b>Fertilizer</b>: " + fertilizer + "\n" + //
				"  <li><b>Other</b>: " + other + "\n" + //

				"</ul>\n");

		out.println("<a href=/PlantDatabase/InsertPlants.html>Search Data</a> <br>");
		out.println("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}