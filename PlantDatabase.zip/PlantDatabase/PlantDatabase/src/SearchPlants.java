import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchPlants")
public class SearchPlants extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SearchPlants() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name_keyword = request.getParameter("name_keyword");
		String water_keyword = request.getParameter("water_keyword");
		String soil_keyword = request.getParameter("soil_keyword");
		String sunlight_keyword = request.getParameter("sunlight_keyword");
		String fertilizer_keyword = request.getParameter("fertilizer_keyword");
		search(name_keyword, water_keyword, soil_keyword, sunlight_keyword, fertilizer_keyword, response);
	}

	void search(String name_keyword, String water_keyword, String soil_keyword, 
			String sunlight_keyword, String fertilizer_keyword, HttpServletResponse response) throws IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String title = "Database Result";
		String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + //
				"transitional//en\">\n"; //
		out.println(docType + //
				"<html>\n" + //
				"<head><title>" + title + "</title></head>\n" + //
				"<body bgcolor=\"#f0f0f0\">\n" + //
				"<h1 align=\"center\">" + title + "</h1>\n");

		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			PlantDBConnection.getDBConnection();
			connection = PlantDBConnection.connection;
			if (name_keyword.isEmpty() && water_keyword.isEmpty() && soil_keyword.isEmpty()
					&& sunlight_keyword.isEmpty() && fertilizer_keyword.isEmpty()) {
				String selectSQL = "SELECT * FROM Plants";
				preparedStatement = connection.prepareStatement(selectSQL);
			} else if (name_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE water LIKE ? OR soil LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String water = "%" + water_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(2, water);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
				
			} else if (water_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR soil LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if (soil_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if (sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR soil LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String soil = "%" + soil_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(5, fertilizer);
			} else if (fertilizer_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR soil LIKE ? OR sunlight LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
			} else if (name_keyword.isEmpty() && water_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE soil LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?";  
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if (name_keyword.isEmpty() && water_keyword.isEmpty() && soil_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE sunlight LIKE ? OR fertilizer LIKE ?"; 
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if ((name_keyword.isEmpty() && water_keyword.isEmpty() && soil_keyword.isEmpty() && sunlight_keyword.isEmpty())) { 
				String selectSQL = "SELECT * FROM Plants WHERE fertilizer LIKE ?"; 
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(5, fertilizer);
			} else if (water_keyword.isEmpty() && soil_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if (water_keyword.isEmpty() && sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR soil LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(5, fertilizer);
			} else if (water_keyword.isEmpty() && fertilizer_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR soil LIKE ? OR sunlight LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
			} else if (water_keyword.isEmpty() && soil_keyword.isEmpty() && sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(5, fertilizer);
			} else if (water_keyword.isEmpty() && soil_keyword.isEmpty() && fertilizer_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR sunlight LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String sunlight = "%" + sunlight_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(4, sunlight);
			} else if (name_keyword.isEmpty() && soil_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE water LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String water = "%" + water_keyword + "%"; 
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(2, water);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			} else if (soil_keyword.isEmpty() && sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(5, fertilizer);
			} else if (soil_keyword.isEmpty() && sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(5, fertilizer);
			} else if (soil_keyword.isEmpty() && fertilizer_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR sunlight LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(4, sunlight);
			} else if (fertilizer_keyword.isEmpty() && sunlight_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR soil LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String water = "%" + water_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(3, soil);
			} else if (water_keyword.isEmpty() && fertilizer_keyword.isEmpty()) { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR soil LIKE ? OR sunlight LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
			} 
			else { 
				String selectSQL = "SELECT * FROM Plants WHERE name LIKE ? OR water LIKE ? OR soil LIKE ? OR sunlight LIKE ? OR fertilizer LIKE ?"; 
				String name = "%" + name_keyword + "%"; 
				String water = "%" + water_keyword + "%";
				String soil = "%" + soil_keyword + "%";
				String sunlight = "%" + sunlight_keyword + "%";
				String fertilizer = "%" + fertilizer_keyword + "%";
				preparedStatement = connection.prepareStatement(selectSQL);
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, water);
				preparedStatement.setString(3, soil);
				preparedStatement.setString(4, sunlight);
				preparedStatement.setString(5, fertilizer);
			}
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String name1 = rs.getString("name").trim();
				String water1 = rs.getString("water").trim();
				String soil1 = rs.getString("soil").trim();
				String sunlight1 = rs.getString("sunlight").trim();
				String fertilizer1 = rs.getString("fertilizer").trim();

				if ((name_keyword.isEmpty() && water_keyword.isEmpty()) && soil_keyword.isEmpty()
						&& sunlight_keyword.isEmpty() && fertilizer_keyword.isEmpty() || name1.contains(name_keyword)
						|| water1.contains(water_keyword) || soil1.contains(soil_keyword)
						|| sunlight1.contains(sunlight_keyword) || fertilizer1.contains(fertilizer_keyword)) {
					out.println("ID: " + id + ", ");
					out.println("Name: " + name1 + ", ");
					out.println("Water: " + water1 + ", ");
					out.println("Soil: " + soil1 + "<br>");
					out.println("Sunlight: " + sunlight1 + "<br>");
					out.println("Fertilizer: " + fertilizer1 + "<br>");
				}
			}
			out.println("<a href=/PlantDatabase/SearchPlants.html>Search Data</a> <br>");
			out.println("</body></html>");
			rs.close();
			preparedStatement.close();
			connection.close();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException se2) {
			}
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}